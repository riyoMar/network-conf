import { defineConfig } from "vite"

export default defineConfig({
    // root: 'task/chart',
    server: {
      host: '0.0.0.0',
      port: 80
    }
})