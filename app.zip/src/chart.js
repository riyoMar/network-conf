import './style.css'
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables); // required to enable all chart types

const ctx = document.getElementById('myChart');

new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Red', 'Blue', 'Yellow', 'Green'],
    datasets: [{
      label: 'Votes',
      data: [12, 19, 3, 5],
      backgroundColor: ['red', 'blue', 'yellow', 'green']
    }]
  },
});
